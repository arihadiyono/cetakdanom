# Dokumentasi Reverse Engineering & Analisis Modernisasi CetakDanom (FDPOS)

Dokumentasi ini disusun sebagai hasil analisis menyeluruh (*comprehensive reverse engineering*) terhadap repositori aplikasi **CetakDanom / FDPOS (Fund Distribution PT Pos Indonesia)** berbasis Borland Delphi 5 dan Delphi 7 untuk kepentingan modernisasi sistem perangkat lunak.

---

## 1. Daftar Dokumen Hasil Analisis

Seluruh temuan telah dianalisis dan disimpan ke dalam berkas Markdown terpisah per topik di dalam folder `/docs`:

| No | Dokumen | Topik Pembahasan |
| :---: | :--- | :--- |
| **01** | [01. Ringkasan Eksekutif & Pemahaman Project](file:///d:/CetakDanom/docs/01_ringkasan_eksekutif_dan_pemahaman_project.md) | Ikhtisar sistem, sejarah pengembangan PT Pos Indonesia, domain bantuan sosial (BST, BPNT, Sembako, BLT, YAPI), serta struktur repositori. |
| **02** | [02. Identifikasi Arsitektur Aplikasi](file:///d:/CetakDanom/docs/02_arsitektur_aplikasi.md) | Topologi arsitektur 2-Tier/3-Tier hibrida, dual-mode execution (Online vs Mode Lokal F5), layering, dan *state machine* pemindahan folder berkas. |
| **03** | [03. Identifikasi Database & Model Data](file:///d:/CetakDanom/docs/03_identifikasi_database.md) | RDBMS Microsoft SQL Server (`fd_db_dev_bsm`), katalog lengkap Stored Procedures `SIKAP_*`, skema tabel in-memory Danom, format ekspor BNBA, dan profil `conf.bns`. |
| **04** | [04. Identifikasi Mekanisme Middleware](file:///d:/CetakDanom/docs/04_mekanisme_middleware.md) | Middleware proprietary `NCONN.pas` (Protokol 2P & Dynamic DLL Dispatching), enkripsi `NCrypt` (Blowfish & MD5), kompresi `NZip` (ZLibEx), sesi `NSession`, serta integrasi REST API Gateway WSO2. |
| **05** | [05. Inventaris Seluruh Form](file:///d:/CetakDanom/docs/05_inventaris_seluruh_form.md) | Rincian 21 form (5 Form Aplikasi Utama: Login, Utama, Konfigurasi Server, QuickReport, Updater; serta 16 Form Pustaka & Desainer). |
| **06** | [06. Inventaris Komponen Pihak Ketiga](file:///d:/CetakDanom/docs/06_inventaris_komponen_pihak_ketiga.md) | Analisis komponen VCL eksternal: FastReport (4 & 6.6.12), kbmMemTable v5.00, DCPcrypt, ZLibEx, Indy, RAWPrinter, DevExpress, NextSuite, JVCL, dan BvComponents. |
| **07** | [07. Peta Ketergantungan Antar Modul](file:///d:/CetakDanom/docs/07_dependency_map.md) | Diagram dependensi antar-proyek, graf ketergantungan antar-unit Pascal (`uses`), serta daftar integrasi Win32 API native. |
| **08** | [08. Aturan Bisnis Utama (Business Rules)](file:///d:/CetakDanom/docs/08_business_rules.md) | Logika bisnis autentikasi, proteksi cetak ganda, aturan tanda petik NIK pada BNBA CSV, susunan payload QR Code kuitansi, rumus CDS BLT, dan syarat program Sembako. |
| **09** | [09. Analisis Risiko Migrasi ke Delphi Modern](file:///d:/CetakDanom/docs/09_risiko_migrasi_delphi_modern.md) | Evaluasi migrasi ke Delphi 11/12 (isu Unicode UTF-16, file C `.obj` 32-bit, DFM 88 MB, lisensi kbmMemTable, dan transisi ke FireDAC). |
| **10** | [10. Analisis Risiko Migrasi ke C# .NET](file:///d:/CetakDanom/docs/10_risiko_migrasi_csharp_dotnet.md) | Evaluasi migrasi ke C# .NET 8/9 (WPF/Avalonia, Dapper SQL Server, penggantian kbmMemTable dengan SQLite, QuestPDF, dan WinSpool P/Invoke passbook). |
| **11** | [11. Analisis Risiko Migrasi ke Tauri](file:///d:/CetakDanom/docs/11_risiko_migrasi_tauri.md) | Evaluasi migrasi ke Tauri v2 + Rust (presisi cetak web vs headless PDF, penanganan passbook ESC/P via FFI, konektivitas database, dan learning curve Rust). |
| **12** | [12. Rencana Implementasi & Timeline Migrasi C# + Go](file:///d:/CetakDanom/docs/12_rencana_migrasi_dan_timeline_csharp_go.md) | Panduan langkah demi langkah implementasi teknis, pemetaan fitur Delphi ke C# dan Go API, serta jadwal kerja (timeline 8 minggu). |
| **13** | [13. Matriks Traceability & Analisis Kesenjangan (Gap Analysis)](file:///d:/CetakDanom/docs/13_matriks_traceability_dan_gap_analysis.md) | Matriks pemetaan Form Delphi → Use Case → Go Endpoint → Stored Procedure, serta analisis gap kritis (Login, Danom, BNBA, CDS BLT, QR Code, Printing, Hak Akses). |
| **14** | [Spesifikasi Kontrak API (api-contract.md)](file:///d:/CetakDanom/docs/api-contract.md) | Kontrak API final untuk seluruh endpoint: URL, Method, Auth, Request/Response DTO, Validasi, Error, Stored Procedure, dan Business Rule. |
| **15** | [OpenAPI 3.0.3 YAML Specification (openapi.yaml)](file:///d:/CetakDanom/docs/openapi.yaml) | Spesifikasi standar Swagger 3.0 / OpenAPI 3.0.3 machine-readable untuk integrasi generator klien/server. |
| **16** | [Katalog Data Transfer Object (dto-catalog.md)](file:///d:/CetakDanom/docs/dto-catalog.md) | Definisi lengkap seluruh struktur DTO Request & Response beserta pemetaan tipe data C#, Go, Delphi, dan SQL Server. |
| **17** | [Aturan Validasi Lengkap (validation-rules.md)](file:///d:/CetakDanom/docs/validation-rules.md) | Aturan validasi field, kontrak payload barcode pipa inter-aplikasi, aturan backtick CSV Excel, hashing MD5 raw, dan katalog kode error standar. |

---

## 2. Matriks Perbandingan Tiga Jalur Modernisasi

| Parameter Evaluasi | Opsi A: Delphi Modern (11/12) | Opsi B: C# (.NET 8/9) | Opsi C: Tauri (Rust + Web) |
| :--- | :---: | :---: | :---: |
| **Keselarasan Ekosistem PT Pos** | Sedang | **Sangat Tinggi (Enterprise Win)** | Sedang |
| **Kematangan Akses SQL Server** | Tinggi (FireDAC) | **Sangat Tinggi (Dapper / SqlClient)** | Sedang (ODBC / Tiberius) |
| **Dukungan Cetak Presisi (Danom)** | **Sangat Tinggi (FastReport VCL)** | **Tinggi (QuestPDF / FastReport .NET)** | Rendah s.d Sedang (Web Print bermasalah) |
| **Dukungan Printer Passbook / RAW** | Tinggi (Native Spooler) | **Tinggi (WinSpool P/Invoke)** | Sedang (Perlu C-FFI Rust) |
| **Keandalan Offline / Local Cache** | Sedang (TFDMemTable) | **Sangat Tinggi (SQLite / EF Core)** | Tinggi (Rusqlite) |
| **Ketersediaan SDM Developer** | Rendah (Komunitas menyusut) | **Sangat Tinggi (Melimpah)** | Rendah (Rust langka & mahal) |
| **Modernitas Antarmuka (UI/UX)** | Sedang (VCL Style) | **Tinggi (WPF / Fluent / Avalonia)** | **Sangat Tinggi (Modern Web/Tailwind)** |
| **Ukuran Biner & Resource RAM** | Sangat Ringan (~15 MB) | Ringan (~30-50 MB Native AOT) | **Sangat Ringan (<15 MB)** |
| **Estimasi Beban Kerja Migrasi** | ~30 Hari Kerja | ~40 Hari Kerja | ~55 Hari Kerja |
| **Tingkat Risiko Proyek Keseluruhan**| **Sedang** | **Paling Rendah (Recommended)** | **Tinggi** |

---

## 3. Rekomendasi Strategis Modernisasi

### Rekomendasi Utama: Migrasi ke C# (.NET 8/9)
Direkomendasikan sebagai pilihan strategis jangka panjang:
1. **Arsitektur Target**: **WPF / Avalonia UI** dengan arsitektur MVVM bersih.
2. **Database & API**: **Dapper** langsung memanggil Stored Procedure SQL Server yang sudah ada, dan `HttpClient` untuk gateway WSO2 CDS BLT.
3. **Penyimpanan Lokal**: Menggantikan berkas `.POS` flat-file dengan basis data lokal **SQLite (terenkripsi)**.
4. **Pencetakan**: Menggunakan **QuestPDF** untuk menghasilkan berkas PDF kuitansi ber-QR Code dengan tata letak presisi tinggi, dan kelas pembantu **`RawPrinterHelper`** untuk printer passbook IBM 9068A / Epson LQ-300.
5. **Ekosistem SDM**: Menjamin kemudahan pemeliharaan (*maintainability*) oleh tim pengembang internal korporat PT Pos Indonesia.

### Opsi Taktis Alternatif: Delphi 12 Athens
Jika terdapat batasan waktu yang sangat ketat (*urgent deployment*) dan organisasi ingin mempertahankan investasi template FastReport yang sudah ada:
- Lakukan refactoring pembersihan DFM 88 MB (pindahkan template ke file eksternal `.fr3`).
- Alihkan kompresi ke `System.ZLib` dan ganti `kbmMemTable` ke `TFDMemTable`.
- Perbaiki seluruh penanganan pointer buffer `AnsiString` &rarr; `TBytes`.

